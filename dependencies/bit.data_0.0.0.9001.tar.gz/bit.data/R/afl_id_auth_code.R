library(httr)

url <- "https://fantasy.afl.com.au/afl_draft/api/aflaccount/auth_code"

payload <- 'code=gaMR4zvcaiJP2MnQwY2IL-IMPoz69aMDqI5teFaH0p4'

headers <- list(
  'Content-Type' = 'application/x-www-form-urlencoded',
  'authority' = 'fantasy.afl.com.au'
  # 'Cookie' = 'session=051f366ebdfa41e3d1f19e00f8bb3269e7855f7f'
)

POST(
  url = url,
  body = payload,
  do.call(what = add_headers, args = headers)
) -> out

content(out)

out$cookies
out$all_headers


url2 <- "https://fantasy.afl.com.au/afl_draft/api/aflaccount/email_check?identity_token=eyJraWQiOiI1VmdZQWE5YXA3ZXh0ZDJxZVZUc1RCZTh3NzI1M1VyRTNQYnUyb3VYZFpzIiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiIwMHUyOXR1Mnk1ODRYbk9xQTNsNyIsIm5hbWUiOiJUaW1vdGh5IEd1bW1lciIsImVtYWlsIjoidGltb3RoeS5ndW1tZXJAZ21haWwuY29tIiwidmVyIjoxLCJpc3MiOiJodHRwczovL2xvZ2luLmlkLmFmbCIsImF1ZCI6IjBvYTI3OG56YTUzVlRlODExM2w3IiwiaWF0IjoxNjczNjk1OTg0LCJleHAiOjE2NzM2OTk1ODQsImp0aSI6IklELmw4Umt2Yk9Ldy00clplTmZEWndfd1lCUlVjbFc3MU5VRE9BYUF1NDNjdlEiLCJhbXIiOlsicHdkIl0sImlkcCI6IjBvYTI4ZW8xYXhBdHF4TzhnM2w3Iiwibm9uY2UiOiI5YWM3Y2MxYS1lZGUyLTQzY2ItODM2ZC1lMjEzNjkyOTU3YjAiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJ0aW1vdGh5Lmd1bW1lckBnbWFpbC5jb20iLCJhdXRoX3RpbWUiOjE2NzM2OTU5NzgsImF0X2hhc2giOiJDYW1YaFBEM0Q2dUpMSkwyYVdoOFNRIn0.YYeko0YY4Oc_CMqAsMd0EDSbxKYhOB-hSTZZjluvAZK8u7jpMmNGT-SunxeVZfxz23wIz6cExYqcbKROEvUYD95JNuklctgW3qYQ4Xp179XILCHCkoB1vHRNacmXKHHHacXDIP0V7zi_4P6xGQyH1hywM25Z-CCp8henAVErz3dmPmhRvP_zHuYBQl8iQHvma9Qn9NRi-TkZjoMRrC1kNSMOxfumWNWbgq3mSaSvcncCB86Mgqa-npshybQ6vRCHMTjQGMPVaH94a8c1I-v_QsDIsp6a5ROWftKqKSX-4Df2XCnNOJTBhEXMabgklrW8m4MR_jdAiKQU4FTqhIqfhA"

out2 <- GET(url2)
content(out2)$result$session_id


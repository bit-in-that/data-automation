# get AFL Fantasy metadata
#
#' Get information on AFL squads, venues and fixtures from the afl fantasy website.
#'
#' @name get-metadata
NULL

#' @export
#' @name get-metadata
get_af_clubs_raw <- function() {
  response <- httr::GET(
    url = "https://fantasy.afl.com.au/data/afl/squads.json"
  )
  stopifnot(response$status_code == 200)
  content <- httr::content(response)
  content
}

#' @export
#' @name get-metadata
get_af_venues_raw <- function() {
  response <- httr::GET(
    url = "https://fantasy.afl.com.au/data/afl/venues.json"
  )
  stopifnot(response$status_code == 200)
  content <- httr::content(response)
  content
}

#' @export
#' @name get-metadata
get_af_rounds_raw <- function() {
  response <- httr::GET(
    url = "https://fantasy.afl.com.au/data/afl/rounds.json"
  )
  stopifnot(response$status_code == 200)
  content <- httr::content(response)
  content
}

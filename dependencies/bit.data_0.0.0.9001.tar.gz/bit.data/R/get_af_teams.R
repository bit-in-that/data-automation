# get AFL Fantasy teams
#
#' Get afl fantasy teams in a list format
#'
#' @param session_id The session cookie in the AFL fantasy website. This can be obtained in chrome by following the following steps:
#' * log in to the AFL fantasy website
#' * hit the F12 key
#' * click the 'Application' tab
#' * go to 'Cookies'
#' * then 'https://fantasy.afl.com.au'
#' * then copy the value named 'Session' (it should be a string of length 40)
#' @param team_id team id for the team you want to lookup
#' @param round_num Round number to pull the data from
#'
#'
#' @name get-af-teams
NULL

# my own team:
# https://fantasy.afl.com.au/afl_classic/api/teams_classic/show_my
#' @name get-af-teams
#' @export
get_af_my_lineup_raw <- function(session_id, round_num = NULL) {
  base_url <- "https://fantasy.afl.com.au/afl_classic/api/teams_classic/show_my"

  query <- list(
    round = round_num
  )

  response <- httr::GET(
    url = base_url,
    query = query,
    httr::set_cookies(session = session_id)
  )

  stopifnot(response$status_code == 200)
  content <- httr::content(response)
  stopifnot(content$success == 1)
  content$result
}


#' @name get-af-teams
#' @export
get_af_classic_lineup_raw <- function(session_id, team_id, round_num = NULL) {
  base_url <- "https://fantasy.afl.com.au/afl_classic/api/teams_classic/show"

  query <- list(
    id = team_id,
    round = round_num
  )

  response <- httr::GET(
    url = base_url,
    query = query,
    httr::set_cookies(session = session_id)
  )

  stopifnot(response$status_code == 200)
  content <- httr::content(response)
  stopifnot(content$success == 1)
  content$result
}


get_af_my_lineup_clean <- function(session_id, round_num = NULL) {
  clean_af_classic_lineup(get_af_my_lineup_raw(session_id, round_num))
}




get_af_top_rankings_raw <- function(session_id, offset = 0, order = "rank", round_num = NULL, sort_top_first = TRUE, state = NULL, club = NULL) {
  # TODO: make it easier to look up states and teams using their names by creating a mapping between them
  base_url <- "https://fantasy.afl.com.au/afl_classic/api/teams_classic/rankings"

  query <- list(
    order = order,
    offset = offset,
    round = round_num,
    state = state,
    club = club,
    order_direction = ifelse(sort_top_first, "ASC", "DESC")
  )

  response <- httr::GET(
    url = base_url,
    query = query,
    httr::set_cookies(session = session_id)
  )

  stopifnot(response$status_code == 200)
  content <- httr::content(response)
  stopifnot(content$success == 1)
  content$result
}

clean_af_top_rankings <- function(raw_list) {

  list_of_dfs <- lapply(raw_list, function(x) {
    x_out <- x
    round_ch <- names(x$league_scoreflow)
    x_out$round <- as.integer(round_ch)
    if(!is.null(x_out$league_scoreflow)) {
      x_out$league_scoreflow <- unlist(x_out$league_scoreflow)
    }
    if(!is.null(x_out$rank_history)) {
      x_out$rank_history <- unlist(x_out$rank_history)
    }

    x_out <- lapply(x_out, function(y) {
      if(length(y) == 0) {
        NA
      } else {
        y
      }
    })

    as.data.frame(x_out)
  })

  do.call(rbind, list_of_dfs)
}

get_af_top_rankings_clean <- function(session_id, offset = 0, order = "rank", round_num = NULL, sort_top_first = TRUE, state = NULL, club = NULL) {
  clean_af_top_rankings(get_af_top_rankings_raw(
    session_id = session_id,
    offset = offset,
    order = order,
    round_num = round_num,
    sort_top_first = sort_top_first,
    state = state,
    club = club
    ))
}


clean_af_user_rank <- function(raw_list) {
  x_out <- raw_list
  round_ch <- names(raw_list$league_scoreflow)
  x_out$round <- as.integer(round_ch)
  if(!is.null(x_out$scoreflow)) {
    x_out$scoreflow <- unlist(x_out$scoreflow)
  }
  if(!is.null(x_out$league_scoreflow)) {
    x_out$league_scoreflow <- unlist(x_out$league_scoreflow)
  }
  if(!is.null(x_out$rank_history)) {
    x_out$rank_history <- unlist(x_out$rank_history)
  }
  if(!is.null(x_out$round_rank_history)) {
    x_out$round_rank_history <- unlist(x_out$round_rank_history)
  }

  x_out <- lapply(x_out, function(y) {
    if(length(y) == 0) {
      NA
    } else {
      y
    }
  })

  as.data.frame(x_out)

}

get_af_user_rank_clean <- function(session_id, user_id, round_num = NULL) {
  clean_af_user_rank(get_af_user_rank_raw(
    session_id = session_id,
    user_id = user_id,
    round_num = round_num
  ))
}


clean_af_classic_lineup <- function(raw_list) {
  x_out <- raw_list
  x_names <- names(raw_list)
  x_lineup <- raw_list$lineup
  # don't need scoreflow because can get elsewhere
  x_out <- x_out[-which(x_names %in% c("scoreflow", "lineup"))]

  defenders_ground_ids <- unlist(x_lineup$`1`)
  defenders_ground <- data.frame(
    player_id = defenders_ground_ids,
    on_ground = TRUE,
    position = paste0("D", seq_along(defenders_ground_ids)),
    line = "Defender",
    is_utility = FALSE
    )
  defenders_bench_ids <- unlist(x_lineup$bench$`1`)
  defenders_bench <- data.frame(
    player_id = defenders_bench_ids,
    on_ground = FALSE,
    position = paste0("D", length(defenders_ground_ids) + seq_along(defenders_bench_ids)),
    line = "Defender",
    is_utility = seq_along(defenders_bench_ids) == 3
    )

  midfielders_ground_ids <- unlist(x_lineup$`2`)
  midfielders_ground <- data.frame(
    player_id = midfielders_ground_ids,
    on_ground = TRUE,
    position = paste0("M", seq_along(midfielders_ground_ids)),
    line = "Midfielder",
    is_utility = FALSE
  )
  midfielders_bench_ids <- unlist(x_lineup$bench$`2`)
  midfielders_bench <- data.frame(
    player_id = midfielders_bench_ids,
    on_ground = FALSE,
    position = paste0("M", length(midfielders_ground_ids) + seq_along(midfielders_bench_ids)),
    line = "Midfielder",
    is_utility = seq_along(midfielders_bench_ids) == 3
  )

  rucks_ground_ids <- unlist(x_lineup$`3`)
  rucks_ground <- data.frame(
    player_id = rucks_ground_ids,
    on_ground = TRUE,
    position = paste0("R", seq_along(rucks_ground_ids)),
    line = "Ruck",
    is_utility = FALSE
  )
  rucks_bench_ids <- unlist(x_lineup$bench$`3`)
  rucks_bench <- data.frame(
    player_id = rucks_bench_ids,
    on_ground = FALSE,
    position = paste0("R", length(rucks_ground_ids) + seq_along(rucks_bench_ids)),
    line = "Ruck",
    is_utility = seq_along(rucks_bench_ids) == 2
  )

  forwards_ground_ids <- unlist(x_lineup$`4`)
  forwards_ground <- data.frame(
    player_id = forwards_ground_ids,
    on_ground = TRUE,
    position = paste0("F", seq_along(forwards_ground_ids)),
    line = "Forward",
    is_utility = FALSE
  )
  forwards_bench_ids <- unlist(x_lineup$bench$`4`)
  forwards_bench <- data.frame(
    player_id = forwards_bench_ids,
    on_ground = FALSE,
    position = paste0("F", length(forwards_ground_ids) + seq_along(forwards_bench_ids)),
    line = "Forward",
    is_utility = seq_along(forwards_bench_ids) == 3
  )

  if(!is.null(x_out$scoreflow)) {
    x_out$scoreflow <- unlist(x_out$scoreflow)
  }
  if(!is.null(x_out$league_scoreflow)) {
    x_out$league_scoreflow <- unlist(x_out$league_scoreflow)
  }
  if(!is.null(x_out$rank_history)) {
    x_out$rank_history <- unlist(x_out$rank_history)
  }
  if(!is.null(x_out$round_rank_history)) {
    x_out$round_rank_history <- unlist(x_out$round_rank_history)
  }

  lineup_df <- rbind(
    defenders_ground,
    defenders_bench,
    midfielders_ground,
    midfielders_bench,
    rucks_ground,
    rucks_bench,
    forwards_ground,
    forwards_bench
  )

  lineup_df$is_emergency <- lineup_df$player_id %in% unlist(x_lineup$bench$emergency)
  lineup_df$is_captian <- if(length(x_lineup$captain) != 0) {
    lineup_df$player_id == x_lineup$captain
  } else {
    FALSE
  }
  lineup_df$is_vice_captain <- if(length(x_lineup$vice_captain) != 0) {
    lineup_df$player_id == x_lineup$vice_captain
  } else {
    FALSE
  }

  x_out <- lapply(x_out, function(y) {
    if(length(y) == 0) {
      NA
    } else {
      y
    }
  })


  x_out = cbind(
    x_out,
    lineup_df
  )

  as.data.frame(x_out)

}

get_af_classic_lineup_clean <- function(session_id, team_id, round_num = NULL) {
  clean_af_classic_lineup(get_af_classic_lineup_raw(
    session_id = session_id,
    team_id = team_id,
    round_num = round_num
  ))
}



# data from the footy live app

footy_live_comp_map <- list(
  "AFL" = "014",
  "NAB League" = "011",
  "PreSeason" = "101",
  "VFL" = "015",
  "SANFL" = "016",
  "WAFL" = "120"
)

get_current_year <- function() {
  as.integer(format(Sys.time(),format = "%Y"))
}

generate_footy_live_game_code <- function(year = get_current_year(), competition = "AFL", round_num = 1L, game_num = 1L) {
  year <- checkmate::assert_int(year,
                                lower = 2014L, # AFL data goes back to 2014 (there could be an older archive)
                                upper = get_current_year(),
                                coerce = TRUE)


  comp_pattern <- paste0("^(",
    paste(names(footy_live_comp_map), collapse = "|"),
  ")$")
  checkmate::assert_string(competition,
                           pattern = comp_pattern)

  comp_code <- footy_live_comp_map[[competition]]

  round_num <- checkmate::assert_int(round_num,
                                     lower = 1L,
                                     upper = 99L,
                                     coerce = TRUE)

  if(round_num < 10) {
    round_num <- paste0("0", round_num)
  }

  game_num <- checkmate::assert_int(game_num,
                                    lower = 1L,
                                    upper = 99L,
                                    coerce = TRUE)
  if(game_num < 10) {
    game_num <- paste0("0", game_num)
  }

  paste0(year, comp_code, round_num, game_num)
}

get_footy_live_raw <- function(year = get_current_year(), competition = "AFL", round_num = 1L, game_num = 1L) {
  game_code <- generate_footy_live_game_code(year, competition, round_num, game_num)
  url <- paste0("http://afl.lookoutdata.com/live/feeds/m//livematch/4/", game_code)
  response <- httr::GET(url)
  stopifnot(response$status == 200)
  out <- httr::content(response, encoding = "UTF-8")
  jsonlite::parse_json(out)
}

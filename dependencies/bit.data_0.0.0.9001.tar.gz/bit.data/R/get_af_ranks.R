# get AFL Fantasy ranks
#
#' Get the rankings for an afl fantasy user's classic team in a list format
#'
#' @param user_id user id for the team you want to lookup
#' @inheritParams get-af-teams
#'
#'
#' @name get-af-ranks
NULL

#' @name get-af-ranks
#' @export
get_af_user_rank_raw <- function(session_id, user_id, round_num = NULL) {
  base_url <- "https://fantasy.afl.com.au/afl_classic/api/teams_classic/snapshot"
  
  query <- list(
    user_id = user_id,
    round = round_num
  )
  
  response <- httr::GET(
    url = base_url,
    query = query,
    httr::set_cookies(session = session_id)
  )
  
  stopifnot(response$status_code == 200)
  content <- httr::content(response)
  stopifnot(content$success == 1)
  content$result
}

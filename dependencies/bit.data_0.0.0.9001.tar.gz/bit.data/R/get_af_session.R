#' Get AFL fantasy session ID
#'
#' Supply your login credentials to get a session ID cookie.
#'
#' @param email Email for your AFL Fantasy account.
#' @param password Password for your AFL Fantasy account.
#'
#' @return A character of length 1 containing the session ID used to access
#' certain types of data (e.g. other coach's full teams).
#'
#' @details The function, `get_af_session_hc()` accepts hard-coded arguments and `get_af_session_gui()` accepts arguments via a gui written in shiny.
#'
#' @name af-session-id
NULL

#' @name af-session-id
#' @export
get_af_session_hc <- function(email, password = askpass::askpass("Enter the password for your AFL fantasy account.")) {
  checkmate::assert_string(email)
  checkmate::assert_string(password)

  httr::POST(
    "https://fantasy.afl.com.au/afl_draft/api/auth/login",
    body = list(
      login = email,
      password = password
    )
  ) -> login
  checkmate::assert_set_equal(login$status_code, 200L)
  login_content <- httr::content(login)
  checkmate::assert(identical(login_content$errors, list()))
  login_content$result$session_id
}

#' @name af-session-id
#' @export
get_af_session_gui <- function() {
  ui <- shiny::fluidPage(
    shiny::textInput("email", "Email:"),
    shiny::passwordInput("password", "Password:"),
    shiny::actionButton("go", "Go")
  )
  server <- function(input, output) {
    shiny::observeEvent(input$go, {
      session_id <- get_af_session_hc(input$email, input$password)
      shiny::stopApp(session_id)
    })
  }
  shiny::runGadget(
    ui,
    server,
    viewer = shiny::dialogViewer(
      dialogName = "AFL Fantasy Login",
      width = 100,
      height = 100)
    )
}

# get players full data
#
#' Get individual player data from the fantasy website in a list format.
#'
#' @param player_id ID used by the AFL website for the player.
#'
#' @name get-af-players
NULL

#TODO: list all the info in each dataset above (and potentially change the name of the function that gets all the data)

#' @name get-af-players
#' @export
get_af_players_all_raw <- function() {
  response <- httr::GET(
    url = "https://fantasy.afl.com.au/data/afl/players.json"
  )
  stopifnot(response$status_code == 200)
  content <- httr::content(response)
  content
}

#' @name get-af-players
#' @export
get_af_players_all2_raw <- function() {
  response <- httr::GET(
    url = "https://fantasy.afl.com.au/data/afl/coach/players.json"
  )
  stopifnot(response$status_code == 200)
  content <- httr::content(response)
  content
}

#' @name get-af-players
#' @export
get_af_player_individual_raw <- function(player_id) {
  response <- httr::GET(
    url = paste0("https://fantasy.afl.com.au/data/afl/stats/players/", player_id, ".json")
  )
  stopifnot(response$status_code == 200)
  content <- httr::content(response)
  content
}


"https://fantasy.afl.com.au/data/afl/coach/players.json" # draft ownership
"https://fantasy.afl.com.au/data/afl/stats/players_opponents_stats.json"
"https://fantasy.afl.com.au/data/afl/stats/players_venues_stats.json"
"https://fantasy.afl.com.au/afl_draft/api/players/favourites"
